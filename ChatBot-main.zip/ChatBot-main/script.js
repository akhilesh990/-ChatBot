let chatbotMsgList = ["Hi", "Hey", "Good Morning", "Good Evening", "How can I help you?", "Thank You"];

let chatContainerElement = document.getElementById("chatContainer");
let userInputElement = document.getElementById("userInput");


function sendMsgToChatBot() {

    let userInputValue = userInputElement.value;
    let inputMsgContainer = document.createElement("div");
    inputMsgContainer.classList.add("msg-to-chatbot-container");
    chatContainerElement.appendChild(inputMsgContainer);

    let inputMessage = document.createElement("span");
    inputMessage.classList.add("msg-to-chatbot");
    inputMessage.textContent = userInputValue;
    inputMsgContainer.appendChild(inputMessage);
    userInputElement.value = "";
    getMsgFromChatbot();
}

function getMsgFromChatbot() {

    let length = chatbotMsgList.length;
    let msgFromBotEl = chatbotMsgList[Math.ceil(Math.random() * length) - 1];

    let BotMsgContainer = document.createElement("div");
    BotMsgContainer.classList.add("msg-from-chatbot-container");
    chatContainerElement.appendChild(BotMsgContainer);

    let botMsg = document.createElement("span");
    botMsg.textContent = msgFromBotEl;
    botMsg.classList.add("msg-from-chatbot");
    BotMsgContainer.appendChild(botMsg);
}